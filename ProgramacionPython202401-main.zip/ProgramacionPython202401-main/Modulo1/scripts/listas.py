# crear 10 variables

# listas -> colecciones de datos 
#          las listas me ayudan a almacenar un conjunto de valores

lista_valores = ["gola", "xyz", 123, True, 34.5, False]


print(f'Imprimo elemento 0 de la lista {lista_valores[0]}')



print(f'Imprimo elemento ultimo elemento de la lista {lista_valores[-1]}')


