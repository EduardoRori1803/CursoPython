base = int(input("Ingrese la base: "))
altura = int(input("Ingrese la altura: "))

area = base * altura/2
print(area)